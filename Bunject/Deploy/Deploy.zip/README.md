Bunject is a library that injects and wraps around significant portions of the PtdB behavior, to standardize injection of custom behavior. 

Primarily used by BNYS.

THIS MOD WILL HAVE NO EFFECT ON IT'S OWN.  This mod is to be used as a dependency by other mods.